import logo from './logo.svg';
import './App.css';
import BaiTapThucHanhLayout from './BaiTapLayoutComponent/BaiTapThucHanhLayout';

function App() {
  return (
    <div className="App">
      <BaiTapThucHanhLayout/>

    </div>
  );
}

export default App;
